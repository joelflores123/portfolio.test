from django.contrib import admin
from .models import Project, Experiences, Education

admin.site.register(Project)
admin.site.register(Experiences)
admin.site.register(Education)