
from django.urls import path
from . import views

app_name = 'core'  

urlpatterns = [
    path('', views.home, name='home'),
    path('educations/', views.education_list, name='education_list'),
    path('educations/create/', views.education_create, name='education_create'),
    path('educations/<int:pk>/edit/', views.education_update, name='education_update'),
    path('educations/<int:pk>/delete/', views.education_delete, name='education_delete'),
]
