from django.shortcuts import render, redirect, get_object_or_404
from .models import Project, Experiences, Education
from .forms import EducationForm  # Asegúrate de importar EducationForm desde forms.py
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.db import IntegrityError
from django.contrib.auth import login, logout, authenticate

def home(request):
    projects = Project.objects.all()
    experiences = Experiences.objects.all()
    education = Education.objects.all()

    return render(request, 'home.html', {
        'projects': projects, 
        'experiences': experiences, 
        'education': education
    })

def signup(request):
    if request.method == "GET":
        return render(request, "signup.html", {
            "form": UserCreationForm()
        })
    else:
        form = UserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                login(request, user)
                return redirect("home")
            except IntegrityError:
                return render(request, "signup.html", {
                    "form": form,
                    "error": "El usuario ya existe"
                })
        else:
            return render(request, "signup.html", {
                "form": form,
                "error": "El formulario no es válido"
            })

def signout(request):
    logout(request)
    return redirect("home")

def signin(request):
    if request.method == "GET":
        return render(request, "signin.html", {
            "form": AuthenticationForm()
        })
    else:
        user = authenticate(
            request, username=request.POST["username"], password=request.POST["password"]
        )
        if user is None:
            return render(request, "signin.html", {
                "form": AuthenticationForm(),
                "error": "El nombre de usuario o la contraseña son incorrectos"
            })
        else:
            login(request, user)
            return redirect("home")

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .models import Education
from .forms import EducationForm

@login_required
def education_list(request):
    data = {"title": "Educación", "title1": "Lista de Educaciones"}
    educations = Education.objects.all()
    data["educations"] = educations
    return render(request, "core/education/list.html", data)

@login_required
def education_create(request):
    data = {"title": "Educación", "title1": "Añadir Educación"}
    if request.method == "POST":
        form = EducationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("core:education_list")
        else:
            data["form"] = form
            data["error"] = "Error al crear la educación."
            return render(request, "core/education/form.html", data)
    else:
        form = EducationForm()
        data["form"] = form
    return render(request, "core/education/form.html", data)

@login_required
def education_update(request, id):
    data = {"title": "Educación", "title1": "Editar Educación"}
    education = get_object_or_404(Education, pk=id)  # Manejo de error
    if request.method == "POST":
        form = EducationForm(request.POST, instance=education)
        if form.is_valid():
            form.save()
            return redirect("core:education_list")
        else:
            data["form"] = form
            data["error"] = "Error al editar la educación."
            return render(request, "core/education/form.html", data)
    else:
        form = EducationForm(instance=education)
        data["form"] = form
    return render(request, "core/education/form.html", data)

@login_required
def education_delete(request, id):
    education = get_object_or_404(Education, pk=id)  # Manejo de error
    if request.method == "POST":
        education.delete()  # Elimina el objeto
        return redirect("core:education_list")  # Redirige a la lista después de la eliminación
    return render(request, "core/education/confirm_delete.html", {"education": education})
