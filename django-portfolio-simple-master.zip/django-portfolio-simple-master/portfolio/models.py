from django.db import models

from django.db import models
from django.db.models.fields import CharField, DateField, URLField
from django.db.models.fields.files import ImageField
from datetime import date
import datetime


class Project(models.Model):
    title = CharField(max_length=100)
    description = CharField(max_length=250)
    image = ImageField(upload_to="portfolio/images")
    url = URLField(blank=True)
    date = DateField(default=date.today)

class Experiences(models.Model):
    institution = CharField(max_length=100)
    description = CharField(max_length=250)
    date = models.DateTimeField(datetime.date.today())
    hours = models.IntegerField()

    def __str__(self):
        return f"{self.institution} - {self.description} ({self.date})"

class Education(models.Model):
    title = CharField(max_length=150)  # Título o grado obtenido
    institution = CharField(max_length=200)  # Nombre de la institución educativa
    start_year = DateField(default=date.today)  # Año de inicio
    end_year = DateField(null=True, blank=True)  # Año de finalización (puede ser nulo)
    description = CharField(max_length=250, blank=True, null=True)  # Descripción opcional

    def __str__(self):
        return f"{self.title} en {self.institution} ({self.start_year} - {self.end_year})"
    
    
